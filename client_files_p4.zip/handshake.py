#!/usr/bin/env python3

import socket

import ssl

import sys

import pprint



def main():

    if len(sys.argv) < 2:

        print("Usage: python handshake.py <hostname>")

        sys.exit(1)



    hostname = sys.argv[1]

    port = 443

    cadir = '/client-certs'  # CA certificates directory



    # Set up the TLS context

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

    context.load_verify_locations(capath=cadir)

    context.verify_mode = ssl.CERT_REQUIRED

    context.check_hostname = False



    # Creating TCP connection

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    sock.connect((hostname, port))

    print("TCP connection established.")



    # Wrapping the socket with the TLS

    ssock = context.wrap_socket(sock, server_hostname=hostname, do_handshake_on_connect=False)



    # TLS handshake

    ssock.do_handshake()

    print("TLS handshake completed.")



    # Printing cipher used

    cipher_used = ssock.cipher()

    print("Cipher used:", cipher_used)



    # Printing the server's certificate

    server_cert = ssock.getpeercert()

    print("Server certificate:")

    pprint.pprint(server_cert)



    input("Press any key to continue...")



    # Close the TLS Connection

    ssock.shutdown(socket.SHUT_RDWR)

    ssock.close()



if __name__ == "__main__":

    main()

